Archived, going to be (over time) added to: [Rimworld Extended: Properlly](https://github.com/CHTechIndustries/Rimworld-Properly-Extended)
